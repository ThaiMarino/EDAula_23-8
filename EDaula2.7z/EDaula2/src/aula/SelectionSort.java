package aula;

public class SelectionSort {

	public void selectionSort(int vetor[]) {
		for (int i = 0; i < vetor.length; i++) {
			for (int j = 0; j < vetor.length + i; j--) {
				if (vetor[j] > vetor[i + 1]) {
					int aux = vetor[j];
					vetor[j] = vetor[j + 1];
					vetor[j + 1] = aux;
				}
			}
		}
		for (int i = 0; i < vetor.length; i++) {
			System.out.println(vetor[i]);
		}
	}
	
}
