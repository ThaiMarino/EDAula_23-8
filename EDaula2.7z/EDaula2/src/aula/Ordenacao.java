package aula;

import javax.swing.JOptionPane;

public class Ordenacao {

	/*public void bubbleSort(int vetor[]) {
		int tamanho = vetor.length - 1;
		for (int  i = 0; i < tamanho; i++) {
			if (vetor[i] > vetor[i + 1]) {
				int aux = vetor[i];
				vetor[i] = vetor[i + 1];
				vetor[i + 1] = aux;
			}
			
			if (i+1 >= tamanho) {
				i = 0;
				tamanho -= 1;
			}
		}
		
		for (int i = 0; i < vetor.length; i++) {
			System.out.println(vetor[i]);
		}
	}*/
	
	public void bubbleSort(int vetor[]) {
		for (int i = vetor.length - 1; i > 0 ; i--) {
			for (int j = 0; j < vetor.length - i; j++) {
				if (vetor[j] > vetor[j + 1]) {
					int aux = vetor[j];
					vetor[j] = vetor[j + 1];
					vetor[j + 1] = aux;
				}
			}
		}
		for (int i = 0; i < vetor.length; i++) {
			System.out.println(vetor[i]);
		}
	}

	
	// o i fica parado, quem anda as posições é o j
	public void selectionSort(int vetor[]) {
		int indiceMenorValor;
		boolean trocou = false;
		for (int i = 0; i < vetor.length; i++) {
			indiceMenorValor = i;
			for (int j = i; j < vetor.length + i; j++) {
				if (vetor[j] < vetor[indiceMenorValor]) {
				//Nao troca agora
					indiceMenorValor = j;
					trocou = true;
				}
			}
			// troca agora
			if (trocou) {
			int aux;
			aux = vetor[indiceMenorValor];
			vetor[indiceMenorValor] = vetor[i];
			vetor[i] = aux;
			trocou = false;
			}
		}
		for (int i = 0; i < vetor.length; i++) {
			System.out.println(vetor[i]);
		}
	}
	
}
