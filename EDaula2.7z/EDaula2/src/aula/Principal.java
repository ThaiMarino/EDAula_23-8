package aula;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		Vetor v = new Vetor();
		v.preencherVetor();
		JOptionPane.showMessageDialog(null, v);
		//int valorBuscado = Integer.parseInt(JOptionPane.showInputDialog("Digite o elemento a ser buscado: "));
		//Busca buscar = new Busca();
		//System.out.println(buscar.buscaBinariaRecursiva(valorBuscado, vetorOrdenado, 0, vetorOrdenado.length - 1));
		Ordenacao ordenacao = new Ordenacao();
		ordenacao.bubbleSort(v.getVetor());
	
		
	}
}
