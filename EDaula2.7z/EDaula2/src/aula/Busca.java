package aula;

import javax.swing.JOptionPane;

public class Busca {
	
	public void buscaSequencial(int valorBuscado, int vetor[]) {
		boolean achou = false;
		for (int i = 0; i < vetor.length; i++) {
			if (valorBuscado == vetor[i]) {
				achou = true;
				break;
			}
		}
		
		if (achou) {
			JOptionPane.showMessageDialog(null, "ACHOU");
		} else {
			JOptionPane.showMessageDialog(null, "NÃO ACHOU");
		}
	}
	
	//Código de busca binária do Rafael
	public void buscaBinaria(int valorBuscado, int vetor[]) {
		int posicaoInicial = 0;
		int posicaoFinal = vetor.length - 1;
		int meio;
		boolean achou = false;
		while (posicaoInicial <= posicaoFinal) {
			meio = (posicaoInicial + posicaoFinal) / 2;
			if (valorBuscado == vetor[meio]) {
				achou = true;
				break;
			} else if (valorBuscado < vetor[meio]) {
				posicaoFinal = meio - 1;
			}else {
				posicaoInicial = meio + 1;
			}
		}
		if (achou) {
			JOptionPane.showMessageDialog(null, "ACHOU Binário");
		} else {
			JOptionPane.showMessageDialog(null, "NÃO ACHOU  Binário");
		}
	}
	
	public int  buscaBinariaRecursiva(int valorBuscado, int vetor[], int posicaoInicial, int posicaoFinal) {
		int meio = (posicaoInicial + posicaoFinal) / 2;
		
		if (posicaoInicial >= posicaoFinal) {
			return 0;
		} else if (valorBuscado == vetor[meio]) {
			return 1;
		} else if (valorBuscado < vetor[meio]) {
			return buscaBinariaRecursiva(valorBuscado, vetor, posicaoInicial, meio - 1);
		} else {
			return buscaBinariaRecursiva(valorBuscado, vetor, meio + 1, posicaoFinal);
		}
	}
	
	
	/*Código de busca binária que o Rubens fez
	public void buscaBinaria(int valorBuscado, int vetor[]) {
		boolean achou = false;
		int meio;
		int posicaoInicial;
		int tamanhoVetor = vetor.length;
		
		for (posicaoInicial = 0; posicaoInicial < tamanhoVetor; posicaoInicial++) {
			meio = (posicaoInicial + (tamanhoVetor - 1)) / 2;
			if (vetor[meio] == valorBuscado) {
				achou = true;
				break;
			} else if (valorBuscado < vetor[meio]) {
				tamanhoVetor = meio - 1;
			} else {
				posicaoInicial = meio;
			}
		}
		
		if (achou) {
			JOptionPane.showMessageDialog(null, "Achou no  binário!");
		} else {
			JOptionPane.showMessageDialog(null, "Não Achou no binário!");
		}
	}*/
}



