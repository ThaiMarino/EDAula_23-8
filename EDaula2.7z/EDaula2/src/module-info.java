/**
 * 
 */
/**
 * @author Aluno
 *
 */
module EDaula2 {
	requires java.desktop;
}